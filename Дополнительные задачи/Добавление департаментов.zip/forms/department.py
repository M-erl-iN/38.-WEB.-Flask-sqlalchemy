from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField
from wtforms import SubmitField
from wtforms.validators import DataRequired
from wtforms.fields.html5 import EmailField


class DepartmentForm(FlaskForm):
    title = StringField('Department title', validators=[DataRequired()])
    chief = IntegerField("Chief department")
    members = StringField("Members")
    email = EmailField('Email')
    submit = SubmitField('Submit')

